export default function About() {
  return (
    <div className="min-h-screen pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">About Us</h1>
          <p className="text-lg text-gray-600">
            Learn more about UC Facility Management Services and our founder
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <div className="w-64 h-64 mx-auto rounded-full overflow-hidden border-8 border-blue-200 shadow-xl">
              <img
                src="/whatsapp_image_2025-12-18_at_8.04.42_pm.jpeg"
                alt="Founder CHITHAMBARASELVAN"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              CHITHAMBARASELVAN
            </h2>
            <p className="text-lg font-semibold text-blue-600 mb-6">
              Founder, UC Facility Management Services
            </p>

            <div className="space-y-4 text-gray-700">
              <p>
                With a passion for excellence and a commitment to quality service delivery,
                CHITHAMBARASELVAN founded UC Facility Management Services to revolutionize the
                facility management industry.
              </p>
              <p>
                Our vision is to provide comprehensive, professional, and reliable facility
                management solutions that empower businesses to focus on their core operations
                while we take care of their facility needs.
              </p>
              <p>
                We believe that exceptional facility management is the backbone of operational
                excellence, and we are dedicated to delivering nothing but the best to our
                partners.
              </p>
            </div>

            <div className="mt-8 space-y-4">
              <div className="glass-card">
                <h3 className="font-bold text-gray-900 mb-2">Our Mission</h3>
                <p className="text-gray-700">
                  To deliver superior facility management services that enhance the value of our
                  partners' assets and operations.
                </p>
              </div>
              <div className="glass-card">
                <h3 className="font-bold text-gray-900 mb-2">Our Vision</h3>
                <p className="text-gray-700">
                  To be the most trusted and innovative facility management service provider in
                  the industry.
                </p>
              </div>
            </div>
          </div>
        </div>

        <section className="py-20 bg-blue-50 rounded-2xl mb-20">
          <div className="px-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">
              Our Core Values
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                { title: 'Excellence', desc: 'Delivering top-quality services' },
                { title: 'Integrity', desc: 'Building trust through honesty' },
                { title: 'Innovation', desc: 'Continuously improving solutions' },
                { title: 'Partnership', desc: 'Growing together with clients' },
              ].map((value, index) => (
                <div key={index} className="text-center">
                  <h3 className="font-bold text-lg text-blue-600 mb-2">{value.title}</h3>
                  <p className="text-gray-700">{value.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">
            Our Location
          </h2>
          <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-lg p-8 text-center">
            <p className="text-lg text-gray-700 mb-4">
              We are looking for our Head office at Bangalore city or exploring good office space options in prime locations.
            </p>
            <p className="text-gray-600">
              Being strategically located in Bangalore, we serve businesses across the city with world-class facility management solutions.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}
