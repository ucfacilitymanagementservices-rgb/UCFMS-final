import {
  Shield,
  Trash2,
  Droplets,
  Zap,
  Building2,
  Trees,
  Bug,
  Dumbbell,
  Flame,
  Users,
  Wrench,
  Home,
} from 'lucide-react';

const serviceImages: { [key: string]: string } = {
  'Security Service': 'https://images.pexels.com/photos/24234906/pexels-photo-24234906.jpeg?auto=compress&cs=tinysrgb&w=1600&h=900&dpr=2',
  'Housekeeping': 'https://images.pexels.com/photos/3932500/pexels-photo-3932500.jpeg?auto=compress&cs=tinysrgb&w=1600&h=900&dpr=2',
  'STP-WTP': 'https://images.pexels.com/photos/3931603/pexels-photo-3931603.jpeg?auto=compress&cs=tinysrgb&w=1600&h=900&dpr=2',
  'DG Set Management': 'https://images.pexels.com/photos/159366/electricity-power-generation-high-voltage-pylon-159366.jpeg?auto=compress&cs=tinysrgb&w=1600&h=900&dpr=2',
  'Lift Maintenance': 'https://images.pexels.com/photos/169677/pexels-photo-169677.jpeg?auto=compress&cs=tinysrgb&w=1600&h=900&dpr=2',
  'Landscaping': 'https://images.pexels.com/photos/1618519/pexels-photo-1618519.jpeg?auto=compress&cs=tinysrgb&w=1600&h=900&dpr=2',
  'Pest Control': 'https://images.pexels.com/photos/3807517/pexels-photo-3807517.jpeg?auto=compress&cs=tinysrgb&w=1600&h=900&dpr=2',
  'Sump-OHT': 'https://images.pexels.com/photos/821365/pexels-photo-821365.jpeg?auto=compress&cs=tinysrgb&w=1600&h=900&dpr=2',
  'MEP Services': 'https://images.pexels.com/photos/3807517/pexels-photo-3807517.jpeg?auto=compress&cs=tinysrgb&w=1600&h=900&dpr=2',
  'Fire Safety': 'https://images.pexels.com/photos/6437752/pexels-photo-6437752.jpeg?auto=compress&cs=tinysrgb&w=1600&h=900&dpr=2',
  'Gym Management': 'https://images.pexels.com/photos/3807517/pexels-photo-3807517.jpeg?auto=compress&cs=tinysrgb&w=1600&h=900&dpr=2',
  'Front Office': 'https://images.pexels.com/photos/3807517/pexels-photo-3807517.jpeg?auto=compress&cs=tinysrgb&w=1600&h=900&dpr=2',
};

export default function Services() {
  const services = [
    { icon: Shield, title: 'Security Service', desc: 'Professional security personnel and systems' },
    { icon: Users, title: 'Housekeeping', desc: 'Comprehensive cleaning and maintenance' },
    { icon: Droplets, title: 'STP-WTP', desc: 'Water treatment and purification' },
    { icon: Zap, title: 'DG Set Management', desc: 'Diesel generator maintenance and operations' },
    { icon: Building2, title: 'Lift Maintenance', desc: 'Elevator installation and upkeep' },
    { icon: Trees, title: 'Landscaping', desc: 'Outdoor maintenance and beautification' },
    { icon: Bug, title: 'Pest Control', desc: 'Integrated pest management solutions' },
    { icon: Home, title: 'Sump-OHT', desc: 'Water tank maintenance and management' },
    { icon: Wrench, title: 'MEP Services', desc: 'Mechanical, electrical, and plumbing' },
    { icon: Flame, title: 'Fire Safety', desc: 'Fire safety equipment and training' },
    { icon: Dumbbell, title: 'Gym Management', desc: 'Fitness facility operations' },
    { icon: Users, title: 'Front Office', desc: 'Reception and administrative services' },
  ];

  return (
    <div className="min-h-screen pt-20">
      <div
        className="absolute top-20 left-0 right-0 h-96 bg-cover bg-center -z-10 opacity-10"
        style={{
          backgroundImage: 'url(https://images.pexels.com/photos/3966173/pexels-photo-3966173.jpeg?auto=compress&cs=tinysrgb&w=2000&h=1500&dpr=2)',
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Our Services</h1>
          <p className="text-xl text-gray-600">
            Your ultimate goal is smooth operation for our partners
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            const imageUrl = serviceImages[service.title];
            return (
              <div key={index} className="group overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300">
                <div className="relative h-48 overflow-hidden bg-gray-200">
                  {imageUrl && (
                    <img
                      src={imageUrl}
                      alt={service.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-4 left-4">
                    <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                      <Icon size={24} className="text-white" />
                    </div>
                  </div>
                </div>
                <div className="p-6 bg-white">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{service.title}</h3>
                  <p className="text-gray-700">{service.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        <section className="mt-20 bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-12 text-white text-center">
          <h2 className="text-3xl font-bold mb-4">Need a Specific Service?</h2>
          <p className="text-lg mb-8 text-blue-100">
            We offer on-demand services tailored to your unique requirements
          </p>
          <button className="bg-white text-blue-600 font-semibold py-3 px-8 rounded-lg hover:bg-blue-50 transition-colors">
            Request Custom Service
          </button>
        </section>
      </div>
    </div>
  );
}
