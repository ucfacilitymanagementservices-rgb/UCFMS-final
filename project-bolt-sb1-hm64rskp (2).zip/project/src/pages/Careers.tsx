import { useState } from 'react';
import { Briefcase, MapPin, Clock } from 'lucide-react';
import EnquiryModal from '../components/EnquiryModal';

interface JobListing {
  id: string;
  title: string;
  department: string;
  location: string;
  type: 'Full-time' | 'Part-time' | 'Contract';
  description: string;
}

export default function Careers() {
  const [selectedJob, setSelectedJob] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [selectedPosition, setSelectedPosition] = useState<string>('');

  const jobs: JobListing[] = [
    {
      id: '1',
      title: 'Facility Manager',
      department: 'Operations',
      location: 'Mumbai, India',
      type: 'Full-time',
      description:
        'Manage all facility operations, staff, and vendor relationships. Ensure smooth running of all services.',
    },
    {
      id: '2',
      title: 'Assistant Facility Manager',
      department: 'Operations',
      location: 'Mumbai, India',
      type: 'Full-time',
      description:
        'Support facility manager in daily operations and assist with service delivery and compliance.',
    },
    {
      id: '3',
      title: 'Fire Safety Officer',
      department: 'Safety',
      location: 'Pan-India',
      type: 'Full-time',
      description:
        'Manage fire safety systems, conduct training, and ensure compliance with safety regulations.',
    },
    {
      id: '4',
      title: 'Front Office Executive',
      department: 'Administration',
      location: 'Mumbai, India',
      type: 'Full-time',
      description:
        'Handle reception duties, visitor management, and general administrative support.',
    },
    {
      id: '5',
      title: 'Help Desk Support',
      department: 'IT Support',
      location: 'Mumbai, India',
      type: 'Full-time',
      description: 'Provide technical support to staff and clients regarding facility systems.',
    },
    {
      id: '6',
      title: 'Accountant',
      department: 'Finance',
      location: 'Mumbai, India',
      type: 'Full-time',
      description:
        'Manage accounts, invoicing, and financial records for the facility management operations.',
    },
    {
      id: '7',
      title: 'Security Supervisor',
      department: 'Security',
      location: 'Pan-India',
      type: 'Full-time',
      description:
        'Oversee security personnel and maintain security protocols across all facilities.',
    },
    {
      id: '8',
      title: 'Housekeeping Supervisor',
      department: 'Housekeeping',
      location: 'Pan-India',
      type: 'Full-time',
      description:
        'Manage housekeeping teams and ensure high standards of cleanliness and maintenance.',
    },
  ];

  const handleApply = (jobTitle: string) => {
    setSelectedPosition(jobTitle);
    setShowModal(true);
  };

  return (
    <div className="min-h-screen pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Join Our Team</h1>
          <p className="text-xl text-gray-600">
            Build a career with UC Facility Management Services
          </p>
        </div>

        <div className="space-y-6">
          {jobs.map((job) => (
            <div key={job.id} className="glass-card group hover:shadow-xl">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-6">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Briefcase size={18} className="text-blue-600" />
                    <span className="text-sm font-semibold text-blue-600">{job.department}</span>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">{job.title}</h3>
                  <p className="text-gray-700 mb-4">{job.description}</p>
                  <div className="flex flex-col sm:flex-row gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <MapPin size={16} />
                      {job.location}
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock size={16} />
                      {job.type}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => handleApply(job.title)}
                  className="btn-primary whitespace-nowrap h-fit"
                >
                  Apply Now
                </button>
              </div>
            </div>
          ))}
        </div>

        <section className="mt-20 bg-blue-50 rounded-2xl p-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Work With Us?</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { title: 'Growth Opportunities', desc: 'Career development and training programs' },
              { title: 'Competitive Benefits', desc: 'Attractive salary and benefits package' },
              { title: 'Professional Team', desc: 'Work with experienced professionals' },
              { title: 'Work-Life Balance', desc: 'Flexible working arrangements' },
            ].map((item, index) => (
              <div key={index} className="text-center">
                <h3 className="font-bold text-lg text-blue-600 mb-2">{item.title}</h3>
                <p className="text-gray-700 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </section>
      </div>

      <EnquiryModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        type="career"
        position={selectedPosition}
      />
    </div>
  );
}
