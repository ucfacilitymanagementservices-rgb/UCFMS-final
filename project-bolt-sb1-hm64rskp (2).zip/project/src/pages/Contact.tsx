import { useState } from 'react';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';
import EnquiryModal from '../components/EnquiryModal';

export default function Contact() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className="min-h-screen pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Get in Touch</h1>
          <p className="text-xl text-gray-600">
            We're here to help and answer any question you might have
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          <div className="glass-card">
            <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mb-4">
              <Phone size={24} className="text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Call Us</h3>
            <p className="text-gray-700 mb-4">
              Available Monday to Sunday, 8 AM to 8 PM IST
            </p>
            <a href="tel:+919880405254" className="text-blue-600 font-semibold hover:text-blue-700">
              +91 98804 05254
            </a>
          </div>

          <div className="glass-card">
            <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mb-4">
              <Mail size={24} className="text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Email Us</h3>
            <p className="text-gray-700 mb-4">
              We'll respond to your email within 24 hours
            </p>
            <a
              href="mailto:ucfacilitymanagementservices@gmail.com"
              className="text-blue-600 font-semibold hover:text-blue-700 break-all"
            >
              ucfacilitymanagementservices@gmail.com
            </a>
          </div>

          <div className="glass-card">
            <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mb-4">
              <MapPin size={24} className="text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Office Location</h3>
            <p className="text-gray-700">
              Mumbai, India
              <br />
              Service Coverage: Pan-India
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Why Contact Us?</h2>
            <ul className="space-y-4">
              {[
                'Professional consultation for your facility needs',
                'Customized solutions tailored to your requirements',
                'Quick response time and dedicated support',
                'Transparent pricing and detailed quotations',
                '24/7 customer service availability',
              ].map((item, index) => (
                <li key={index} className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-white text-sm font-bold">✓</span>
                  </div>
                  <span className="text-gray-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-12 text-white">
            <h3 className="text-2xl font-bold mb-6">Ready to Get Started?</h3>
            <p className="text-blue-100 mb-8">
              Submit your enquiry and our team will reach out to you with a customized proposal
              within 24 hours.
            </p>
            <button
              onClick={() => setIsModalOpen(true)}
              className="bg-white text-blue-600 font-semibold py-3 px-8 rounded-lg hover:bg-blue-50 transition-colors w-full"
            >
              Submit Enquiry
            </button>
          </div>
        </div>

        <section className="bg-blue-50 rounded-2xl p-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            Business Hours
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            {[
              { day: 'Monday to Friday', time: '8:00 AM - 8:00 PM IST' },
              { day: 'Saturday', time: '9:00 AM - 6:00 PM IST' },
              { day: 'Sunday', time: '10:00 AM - 4:00 PM IST' },
            ].map((schedule, index) => (
              <div key={index} className="flex flex-col items-center">
                <Clock size={24} className="text-blue-600 mb-3" />
                <p className="font-semibold text-gray-900">{schedule.day}</p>
                <p className="text-gray-600">{schedule.time}</p>
              </div>
            ))}
          </div>
        </section>
      </div>

      <EnquiryModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </div>
  );
}
