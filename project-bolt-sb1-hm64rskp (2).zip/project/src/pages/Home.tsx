import { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import EnquiryModal from '../components/EnquiryModal';

export default function Home() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div>
      <section className="min-h-screen relative pt-16 flex items-center">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              'url(https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg)',
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/40 via-blue-500/30 to-transparent" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-20">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
              UC Facility Management Services
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-8 font-light">
              Your ultimate goal is smooth operation for our partners
            </p>
            <button
              onClick={() => setIsModalOpen(true)}
              className="btn-primary-lg inline-flex items-center gap-2 group"
            >
              Enquire Now
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose UC Facilities?
            </h2>
            <p className="text-lg text-gray-600">
              Delivering excellence in facility management across diverse sectors
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'Professional Team',
                description:
                  'Experienced and certified facility management professionals dedicated to your needs',
              },
              {
                title: 'Comprehensive Services',
                description:
                  'Full range of facility services from security to maintenance and everything in between',
              },
              {
                title: '24/7 Support',
                description:
                  'Round-the-clock support to ensure smooth operations at all times',
              },
            ].map((item, index) => (
              <div key={index} className="glass-card">
                <h3 className="text-xl font-bold text-gray-900 mb-3">{item.title}</h3>
                <p className="text-gray-700">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <EnquiryModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </div>
  );
}
